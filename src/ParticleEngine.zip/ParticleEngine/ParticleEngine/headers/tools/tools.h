#pragma once

#ifndef TOOLS_H
#define TOOLS_H

// arrays
int get1DIndex(int, int, int);

// color
int verify256Range(int);

#endif